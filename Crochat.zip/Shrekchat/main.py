import socket
import threading
import time
import pyautogui
from pynput.mouse import Controller as MouseController
from pynput.keyboard import Controller as KeyboardController, Key
from PIL import ImageGrab
import struct
import pickle

# Consent mechanism (4 steps)
def get_consent():
    for i in range(1, 5):
        consent = input(f"Step {i}/4: Do you consent to remote control? (yes/no): ").strip().lower()
        if consent != 'yes':
            print("Consent denied. Exiting.")
            return False
    return True

# Screen capturing function
def capture_screen():
    img = ImageGrab.grab()
    return img

# Function to handle sending screen data
def send_screen(conn):
    try:
        while True:
            img = capture_screen()
            img = img.resize((800, 450))  # Resize for performance
            data = pickle.dumps(img)
            conn.sendall(struct.pack("L", len(data)) + data)
            time.sleep(0.1)  # 10 fps
    except Exception as e:
        print(f"Error: {e}")

# Function to receive and execute remote control commands
def receive_commands(conn):
    mouse = MouseController()
    keyboard = KeyboardController()
    try:
        while True:
            data = conn.recv(1024).decode()
            if not data:
                break
            command = data.split(',')
            if command[0] == "mouse_move":
                x, y = int(command[1]), int(command[2])
                mouse.position = (x, y)
            elif command[0] == "click":
                mouse.click()
            elif command[0] == "key":
                keyboard.press(command[1])
                keyboard.release(command[1])
    except Exception as e:
        print(f"Error: {e}")

# Server function
def server():
    if not get_consent():
        return
    
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
        server.bind(('0.0.0.0', 9999))
        server.listen(1)
        print("Waiting for connection...")
        conn, addr = server.accept()
        print(f"Connected to {addr}")

        threading.Thread(target=send_screen, args=(conn,)).start()
        threading.Thread(target=receive_commands, args=(conn,)).start()

        time.sleep(180)  # 3-minute timeout
        conn.close()
        print("Connection closed.")

# Client function
def client(host):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
        client.connect((host, 9999))
        print("Connected to remote PC")

        while True:
            command = input("Enter command (mouse_move x,y / click / key keyname): ")
            if command == "exit":
                break
            client.sendall(command.encode())

if __name__ == "__main__":
    role = input("Run as (server/client): ").strip().lower()
    if role == "server":
        server()
    elif role == "client":
        host = input("Enter server IP: ")
        client(host)